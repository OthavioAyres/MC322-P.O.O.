package lab02;

public interface Notificavel {
    public void exibirNotificacao(String assunto, String mensagem);
}