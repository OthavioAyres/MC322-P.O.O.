package lab02.exceptions;

public class IngressoEsgotadoException extends Exception {
    public IngressoEsgotadoException(String message) {
        super(message);
    }
} 