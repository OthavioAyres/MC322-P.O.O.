package lab02.exceptions;

public class EventoNaoEncontradoException extends Exception {
    public EventoNaoEncontradoException(String message) {
        super(message);
    }
} 