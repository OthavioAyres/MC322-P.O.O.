package lab01;

interface FiltroEvento {
    boolean filtrar(Evento evento);
}
